
# 📘 Chapitre 24 – Risk Management & Stop-Loss Guard

## 🎯 Objectif de ce module

Ce module vise à sécuriser les ordres de trading en y intégrant automatiquement des ordres stop-loss dynamiques, permettant ainsi de limiter les pertes potentielles de l'utilisateur tout en conservant une certaine marge d'autonomie.

## 🧠 Recommandations IA

La gestion intelligente du risque permet de préserver le capital du trader. Elle repose sur une IA capable de calculer dynamiquement les seuils de stop selon la volatilité, le profil de l’utilisateur et le comportement historique du ticker.

## 🧩 Approche choisie

- Intégration UI avec définition d’un niveau de risque
- Déclenchement automatique d’un ordre stop-loss
- Surveillance en temps réel de l’évolution des cours
- Exécution rapide du stop-loss
- Logging en base de chaque mouvement de sécurité

---

## 🗃️ Base de données utilisée

| Table | Description |
|-------|-------------|
| `risk_parameters` | Niveaux de stop configurés par l’utilisateur |
| `stop_orders` | Ordres de sécurité créés automatiquement |
| `executions` | Historique des ordres déclenchés |
| `risk_logs` | Journalisation des alertes et actions prises |

---

## 📜 User Stories de cet EPIC

➡️ Voir : [`bpmn_epic_24_security_guard_stoploss.xlsx`](../user_stories/bpmn_epic_24_security_guard_stoploss.xlsx)

---

## 📊 Diagramme BPMN

➡️ Voir `/images/bpmn_epic_24_risk_management_stoploss.png`

---

## ⚙️ Conditions critiques

- Si le prix chute sous le seuil de sécurité → exécution immédiate du stop
- Enregistrement de chaque action dans `risk_logs`
- Comparaison entre prix cible et exécution réelle

---

## 🧠 Prompt utilisé

```plaintext
Génère le BPMN pour l’EPIC ‘Risk Management & Stop-Loss’ avec :
UI / Bot / DB / System, seuils de stop, déclenchement conditionnel, logs.
```

---

## ⚠️ Limites connues

- Ne gère pas les stop-loss ajustés automatiquement en cours de session
- Risque de slippage élevé en cas de forte volatilité

---

## 🔁 Références croisées

| Comportement lié | EPIC concerné |
|------------------|----------------|
| Stratégie IA de scoring | EPIC 08 – GPT Scoring |
| Apprentissage des trades | EPIC 16 – Learning Engine |
| Historique des exécutions | EPIC 13 – Simulation & Logs |

---

## 💡 Leçon clé

Un stop-loss bien calibré, exécuté au bon moment, protège le trader mieux qu’un indicateur.
