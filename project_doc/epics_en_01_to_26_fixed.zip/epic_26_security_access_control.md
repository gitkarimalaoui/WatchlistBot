
# EPIC 26 – Security & Access Control

This module manages all logic related to access validation and credential-based security. It ensures proper authentication before granting access to any resource, logs the outcomes, and follows compliance rules.

---

## 🔁 BPMN Diagram

![BPMN – EPIC 26 – Security & Access Control](../images/bpmn_epic_26_security_access_control.png)

---

## ✅ Main Steps

1. **UI** receives access request
2. **User** submits credentials
3. **System** validates the credentials
4. **DB** logs access if granted

---

## 📋 User Stories

- As a system, I want to validate user credentials before allowing access to secure modules.
- As an administrator, I want to log all access attempts to ensure traceability.
- As a user, I want to be notified immediately if access is denied.

---

## 🛠️ Dependencies

- UI Login module
- Credential validator
- Access log database

