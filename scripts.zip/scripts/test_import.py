import pyautogui
import pyperclip

print("✅ Tout est bien installé et prêt à fonctionner.")
