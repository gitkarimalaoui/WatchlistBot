import json
import datetime

TEMPLATES_FILE = "linkedin_message_templates.json"

def generate_linkedin_message(name, position, company, language='en'):
    if language == 'fr':
        return f"Bonjour {name},\n\nJe me permets de vous contacter suite à l'offre de {position} chez {company}. Je suis un consultant expérimenté en transformation numérique avec une expertise en Salesforce et IA.\n\nRestant à votre disposition pour échanger.\n\nBien à vous,\nKarim EL Alaoui"
    else:
        return f"Hi {name},\n\nReaching out regarding the {position} opportunity at {company}. I'm an experienced consultant in digital transformation with deep expertise in Salesforce and AI.\n\nHappy to connect and discuss.\n\nBest regards,\nKarim EL Alaoui"

def save_template(template_name, message):
    try:
        with open(TEMPLATES_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except:
        data = {}

    data[template_name] = {
        "message": message,
        "date": datetime.datetime.now().isoformat()
    }

    with open(TEMPLATES_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

def load_templates():
    try:
        with open(TEMPLATES_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return {}

# Exemple :
if __name__ == "__main__":
    msg = generate_linkedin_message("Sophie", "Salesforce Consultant", "Cognizant", language='fr')
    save_template("Consultant_FR", msg)
    print("Template enregistré et message généré :")
    print(msg)
