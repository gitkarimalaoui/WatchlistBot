import datetime
import uuid
import csv

CALENDAR_FILE = "interview_calendar.csv"

def schedule_meeting(date_str, time_str, subject, contact_email):
    dt_str = f"{date_str} {time_str}"
    dt = datetime.datetime.strptime(dt_str, "%Y-%m-%d %H:%M")
    event_id = str(uuid.uuid4())
    with open(CALENDAR_FILE, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([event_id, dt.isoformat(), subject, contact_email])
    return event_id

def get_all_meetings():
    try:
        with open(CALENDAR_FILE, "r", encoding="utf-8") as f:
            reader = csv.reader(f)
            return [dict(id=row[0], datetime=row[1], subject=row[2], email=row[3]) for row in reader]
    except FileNotFoundError:
        return []

# Exemple :
if __name__ == "__main__":
    schedule_meeting("2025-06-04", "14:00", "Entretien Salesforce", "hr@example.com")
    print("Rendez-vous enregistré. Calendrier actuel :")
    print(get_all_meetings())
