import streamlit as st
import pandas as pd
import sqlite3
import os
import plotly.express as px
from datetime import datetime
from jobtracker_db_model import initialize_jobtracker_db, get_all_applications

# Initialisation base de données
initialize_jobtracker_db()
DB_PATH = "jobtracker.db"

# Configuration de la page
st.set_page_config(
    page_title="Assistant Emploi Automatisé",
    layout="wide",
    page_icon="🧭"
)

st.title("🧭 Assistant Automatisé de Recherche d'Emploi")
st.markdown("---")

# Sidebar options
st.sidebar.header("Filtres")
location_filter = st.sidebar.multiselect("Lieu", ["Ottawa", "Montréal", "Toronto", "Remote"], default=["Ottawa", "Remote"])
lang_filter = st.sidebar.checkbox("Postes bilingues uniquement", value=True)

# Charger les données depuis la base
all_jobs = get_all_applications()
filtered_jobs = []

for job in all_jobs:
    if job['location'] in location_filter:
        if not lang_filter or job['bilingual']:
            filtered_jobs.append(job)

# Statistiques
col1, col2 = st.columns(2)
with col1:
    st.metric("Nombre total d'offres", len(all_jobs))
with col2:
    st.metric("Offres filtrées", len(filtered_jobs))

# Graphique
if filtered_jobs:
    df = pd.DataFrame(filtered_jobs)
    fig = px.histogram(df, x="location", color="status", barmode="group", title="Offres par ville et statut")
    st.plotly_chart(fig, use_container_width=True)

    # Tableau de données
    st.subheader("📋 Détails des offres")
    st.dataframe(df[['date', 'company', 'position', 'location', 'salary', 'status', 'url']].sort_values(by="date", ascending=False))
else:
    st.warning("Aucune offre trouvée avec les filtres actuels.")
