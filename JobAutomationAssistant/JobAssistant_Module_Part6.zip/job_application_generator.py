import datetime
import random
from pathlib import Path

def generate_cover_letter(offer, profile, lang='en'):
    today = datetime.date.today().strftime("%B %d, %Y")
    company = offer.get("company", "the company")
    position = offer.get("position", "this position")
    name = profile.get("name", "Karim EL Alaoui")

    if lang == 'fr':
        letter = f"""{name}
Ottawa, Ontario
{today}

Objet : Candidature au poste de {position} chez {company}

Madame, Monsieur,

Je vous écris pour exprimer mon intérêt pour le poste de {position} chez {company}. Avec plus de 15 ans d'expérience en transformation numérique, architecture Salesforce et intégration de l'intelligence artificielle, je suis convaincu de pouvoir contribuer efficacement à vos projets.

Mes compétences comprennent : {', '.join(profile.get('skills', [])[:5])}. Je suis également certifié {', '.join(profile.get('certifications', [])[:2])}.

Je serais ravi de discuter de cette opportunité avec vous et de vous démontrer ma motivation.

Veuillez agréer, Madame, Monsieur, l'expression de mes salutations distinguées.

{name}
📧 {profile.get("email")}
☎️ {profile.get("phone")}
"""
    else:
        letter = f"""{name}
Ottawa, Ontario
{today}

Subject: Application for {position} at {company}

Dear Hiring Manager,

I am writing to express my interest in the {position} role at {company}. With over 15 years of experience in digital transformation, Salesforce architecture, and AI integration, I am confident in my ability to contribute meaningfully to your projects.

My core skills include: {', '.join(profile.get('skills', [])[:5])}. I am also certified in {', '.join(profile.get('certifications', [])[:2])}.

I would welcome the opportunity to further discuss how I can bring value to your organization.

Sincerely,

{name}
📧 {profile.get("email")}
☎️ {profile.get("phone")}
"""    
    return letter

def save_letter_to_file(letter, filename="cover_letter.txt"):
    path = Path(filename)
    with path.open("w", encoding="utf-8") as f:
        f.write(letter)
    return str(path)

# Exemple d’usage
if __name__ == "__main__":
    offer_sample = {
        "company": "TechNova",
        "position": "Salesforce Consultant"
    }
    profile_sample = {
        "name": "Karim EL Alaoui",
        "email": "karim.alaoui@gmail.com",
        "phone": "613-408-6350",
        "skills": ["Salesforce", "AI", "Agile", "WatsonX", "Integration"],
        "certifications": ["Salesforce Admin", "Omnistudio Consultant"]
    }
    letter = generate_cover_letter(offer_sample, profile_sample, lang="en")
    save_letter_to_file(letter, "sample_cover_letter.txt")
