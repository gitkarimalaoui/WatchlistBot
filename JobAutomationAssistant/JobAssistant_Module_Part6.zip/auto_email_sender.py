import smtplib
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication

def send_job_application(email_config, to_email, subject, body, attachments=[]):
    msg = MIMEMultipart()
    msg['From'] = email_config['from_email']
    msg['To'] = to_email
    msg['Subject'] = subject

    msg.attach(MIMEText(body, 'plain'))

    for filepath in attachments:
        if os.path.exists(filepath):
            with open(filepath, 'rb') as f:
                part = MIMEApplication(f.read(), Name=os.path.basename(filepath))
                part['Content-Disposition'] = f'attachment; filename="{os.path.basename(filepath)}"'
                msg.attach(part)

    try:
        with smtplib.SMTP(email_config['smtp_server'], email_config['smtp_port']) as server:
            server.starttls()
            server.login(email_config['from_email'], email_config['password'])
            server.send_message(msg)
        return True
    except Exception as e:
        print(f"Error sending email: {e}")
        return False

# Exemple d’utilisation :
if __name__ == "__main__":
    config = {
        'from_email': 'your.email@example.com',
        'password': 'your_password',
        'smtp_server': 'smtp.gmail.com',
        'smtp_port': 587
    }
    to = "recruiter@example.com"
    subject = "Application - Salesforce Consultant"
    body = "Dear Hiring Team,\n\nPlease find attached my CV and cover letter for your consideration.\n\nBest regards,\nKarim EL Alaoui"
    attachments = ["Karim_EL_Alaoui_English_Canadian_CV.pdf", "sample_cover_letter.txt"]

    success = send_job_application(config, to, subject, body, attachments)
    print("Email sent:", success)
