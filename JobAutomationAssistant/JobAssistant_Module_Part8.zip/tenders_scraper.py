import requests
from bs4 import BeautifulSoup
from datetime import datetime
import sqlite3
import hashlib

DB_PATH = "quebec_tenders.db"

def init_tenders_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS tenders (
            id TEXT PRIMARY KEY,
            title TEXT,
            url TEXT,
            category TEXT,
            city TEXT,
            deadline TEXT,
            budget TEXT,
            description TEXT,
            date_collected TEXT
        )
    """)
    conn.commit()
    conn.close()

def save_tender(tender):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
        INSERT OR IGNORE INTO tenders (id, title, url, category, city, deadline, budget, description, date_collected)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        tender['id'], tender['title'], tender['url'], tender['category'],
        tender['city'], tender['deadline'], tender['budget'],
        tender['description'], tender['date_collected']
    ))
    conn.commit()
    conn.close()

def scrape_seao(keyword="informatique"):
    url = f"https://www.seao.ca/Recherche/avis"
    params = {
        "Recherche": keyword,
        "critere": keyword,
        "TypeAvis": "Offre"
    }
    response = requests.get(url, params=params)
    soup = BeautifulSoup(response.text, "html.parser")

    tenders = []
    for link in soup.find_all("a", href=True):
        title = link.text.strip()
        if len(title) > 10 and "/avis/details/" in link['href']:
            url_detail = "https://www.seao.ca" + link['href']
            tid = hashlib.md5(url_detail.encode()).hexdigest()
            tenders.append({
                "id": tid,
                "title": title,
                "url": url_detail,
                "category": "Informatique",
                "city": "Québec",
                "deadline": "À valider",
                "budget": "À valider",
                "description": "",
                "date_collected": str(datetime.now().date())
            })
    for t in tenders:
        save_tender(t)
    return tenders

if __name__ == "__main__":
    init_tenders_db()
    results = scrape_seao("Salesforce")
    print(f"{len(results)} offres SEAO sauvegardées.")
