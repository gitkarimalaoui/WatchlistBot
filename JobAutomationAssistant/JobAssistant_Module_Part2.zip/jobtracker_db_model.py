import sqlite3

DB_PATH = "jobtracker.db"

def initialize_jobtracker_db(db_path=DB_PATH):
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS job_applications (
            id TEXT PRIMARY KEY,
            company TEXT,
            position TEXT,
            location TEXT,
            remote INTEGER,
            hybrid INTEGER,
            bilingual INTEGER,
            url TEXT,
            email TEXT,
            salary TEXT,
            date TEXT,
            status TEXT
        )
    """)
    conn.commit()
    conn.close()

def save_job_offer(offer, db_path=DB_PATH):
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("""
        INSERT OR IGNORE INTO job_applications (id, company, position, location, remote, hybrid, bilingual, url, email, salary, date, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        offer.get("id"),
        offer.get("company"),
        offer.get("position"),
        offer.get("location"),
        int(offer.get("remote", False)),
        int(offer.get("hybrid", False)),
        int(offer.get("bilingual", False)),
        offer.get("url"),
        offer.get("email"),
        offer.get("salary"),
        offer.get("date"),
        offer.get("status")
    ))
    conn.commit()
    conn.close()

def get_all_applications(db_path=DB_PATH):
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("SELECT * FROM job_applications")
    rows = cur.fetchall()
    columns = [desc[0] for desc in cur.description]
    conn.close()
    return [dict(zip(columns, row)) for row in rows]

if __name__ == "__main__":
    initialize_jobtracker_db()
