import requests
import hashlib
import time
from jobtracker_db_model import save_job_offer

SERP_API_KEY = "4641687a4efe50785b39fd3277fb1a1b88535c4b92990de5b3e44cd162f00e4c"
SEARCH_ENGINES = ["linkedin", "indeed"]

def generate_offer_id(title, company, location):
    unique_str = f"{title}_{company}_{location}_{time.time()}"
    return hashlib.md5(unique_str.encode()).hexdigest()

def fetch_serpapi_results(query, location="Ottawa, Canada", engine="linkedin_jobs"):
    url = "https://serpapi.com/search.json"
    params = {
        "engine": engine,
        "q": query,
        "location": location,
        "api_key": SERP_API_KEY
    }
    response = requests.get(url, params=params)
    if response.status_code == 200:
        return response.json().get("jobs_results", [])
    return []

def parse_and_store_results(results, location, bilingual_only=True):
    for job in results:
        title = job.get("title", "")
        company = job.get("company_name", "")
        url = job.get("link", "")
        desc = job.get("description", "")
        salary = job.get("detected_extensions", {}).get("salary", "")
        date = job.get("detected_extensions", {}).get("posted_at", str(time.strftime("%Y-%m-%d")))

        bilingual = "bilingual" in desc.lower() or "français" in desc.lower()
        if bilingual_only and not bilingual:
            continue

        offer = {
            "id": generate_offer_id(title, company, location),
            "company": company,
            "position": title,
            "location": location,
            "remote": "remote" in desc.lower(),
            "hybrid": "hybrid" in desc.lower(),
            "bilingual": bilingual,
            "url": url,
            "email": "",
            "salary": salary,
            "date": date,
            "status": "open"
        }

        save_job_offer(offer)

def run_scraping_all(keywords=["Salesforce Consultant"], cities=["Ottawa", "Remote"]):
    for keyword in keywords:
        for city in cities:
            for engine in SEARCH_ENGINES:
                try:
                    results = fetch_serpapi_results(keyword, city, engine)
                    parse_and_store_results(results, city)
                    time.sleep(2)
                except Exception as e:
                    print(f"Error fetching for {keyword} - {city} - {engine}: {e}")

if __name__ == "__main__":
    run_scraping_all()
