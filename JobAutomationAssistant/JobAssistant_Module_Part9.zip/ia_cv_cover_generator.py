import openai
import os
from datetime import datetime

openai.api_key = os.getenv("OPENAI_API_KEY", "sk-xxx")  # Remplacer par clé sécurisée

def generate_cv_and_cover(profile, offer, language='en'):
    prompt = f"""
You are an expert resume and cover letter writer. Given the following user profile and job offer,
generate a tailored resume and a cover letter in {language.upper()}.

USER PROFILE:
{profile}

JOB OFFER:
{offer}

FORMAT:
---RESUME---
[Resume content]

---COVER LETTER---
[Cover letter content]
"""
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.5,
        max_tokens=1500
    )
    content = response['choices'][0]['message']['content']
    return content

if __name__ == "__main__":
    profile = {
        "name": "Karim EL Alaoui",
        "email": "karim.alaoui@gmail.com",
        "experience": "15+ years in IT consulting, Salesforce, AI, Cloud",
        "skills": ["Salesforce", "AI", "Cloud", "SAP", "MuleSoft"]
    }
    offer = {
        "title": "Salesforce Consultant",
        "company": "TechCorp",
        "description": "Looking for a bilingual Salesforce expert for a remote position in digital transformation."
    }
    result = generate_cv_and_cover(profile, offer, "en")
    with open("generated_cv_letter.txt", "w", encoding="utf-8") as f:
        f.write(result)
    print("✔ Résumé and cover letter generated.")
