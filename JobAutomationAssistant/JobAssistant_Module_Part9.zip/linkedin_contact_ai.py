import json
import openai
import os

openai.api_key = os.getenv("OPENAI_API_KEY", "sk-xxx")  # Remplacez par votre clé OpenAI

def generate_linkedin_message(profile, recruiter_info, job_offer, language="en"):
    prompt = f"""
You are an expert in business networking and outreach. Based on the user profile, recruiter info, and job offer below,
generate a short and professional first message for LinkedIn in {language.upper()}.

PROFILE:
{profile}

RECRUITER INFO:
{recruiter_info}

JOB OFFER:
{job_offer}

Format:
---MESSAGE---
[LinkedIn message here]
"""
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.5,
        max_tokens=500
    )
    return response['choices'][0]['message']['content']

if __name__ == "__main__":
    profile = {
        "name": "Karim EL Alaoui",
        "title": "IT Consultant & Salesforce Architect",
        "location": "Ottawa",
        "skills": ["AI", "Salesforce", "Consulting", "Cloud"]
    }
    recruiter_info = {
        "name": "Sophie Tremblay",
        "title": "Recruiter",
        "company": "TechCorp",
        "linkedin": "https://linkedin.com/in/sophie-techcorp"
    }
    job_offer = {
        "title": "Senior Salesforce Consultant",
        "location": "Remote",
        "language": "Bilingual (FR/EN)"
    }

    message = generate_linkedin_message(profile, recruiter_info, job_offer, "en")
    with open("linkedin_outreach_message.txt", "w", encoding="utf-8") as f:
        f.write(message)
    print("✅ LinkedIn message generated.")
