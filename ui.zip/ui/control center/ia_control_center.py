import streamlit as st

st.title("🔍 IA Control Center")

st.write("Centre de contrôle principal de l'IA, gestion des modules et des tests.")