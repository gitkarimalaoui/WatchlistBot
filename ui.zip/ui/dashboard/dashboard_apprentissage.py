import streamlit as st

st.title("🧠 Dashboard Apprentissage")

st.write("Visualisation des patterns gagnants/perdants détectés par l'IA.")